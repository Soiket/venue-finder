

<?php $__env->startSection('client_main'); ?>
    <div style="height: 200px">


    </div>

    <div class="container" style="margin-bottom:50px">
        <div class="row">

            <div class="col-md-4">
                <form action="<?php echo e(route('venueSearch')); ?>" method="GET"
                    style="background-color: rgb(255, 175, 4); padding:20px">                   

                    <div class="form-group">
                        <label for="inputAddress2">Search Venu Name </label>
                        <input type="text" class="form-control" id="venue_name" name="name" placeholder="Venu Name">
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="inputState">Select Division</label>
                            <select class="" id="division" name="division">
                                <option value="">Select One</option>
                                <?php $__currentLoopData = $division; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="inputState">Select Zone</label>
                            <select name="zone" id="zone" class="">
                                <option value="all">Select One</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary" style="text-align: center">Search</button>
                </form>

            </div>

            <div class="col-md-8">
                <h4>Searching result for
                    <?php if(request()->name): ?>
                        <?php echo e(request()->name); ?>

                    <?php elseif(request()->division && request()->zone): ?>
                        Divions / Zones
                    <?php endif; ?>

                </h4>
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <h5 class="card-header"></h5>
                        <div class="card-body">
                            <div class="row">

                                <div class="col-md-4">
                                    <?php if($item->image): ?>
                                        <img src="<?php echo e(asset('images/venue/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>"
                                            class="img-fluid">
                                    <?php else: ?>
                                    <img style="height: 100%" src="https://images.unsplash.com/photo-1551174078-56deb88b8799?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YmFuZ2xhZGVzaCUyMGxvY2F0aW9ufGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60">
                                    <?php endif; ?> 
                                    
                                </div>
                                <div class="col-md-8">
                                    <h5 class="card-title"><?php echo e($item->name); ?></h5>
                                    <a href="<?php echo e($item->location); ?>" class="card-text" style="color: rgb(0, 60, 255)">Show On
                                        Map <i class="fa fa-map-marker fa-2x" aria-hidden="true"></i></a>
                                    <p class="card-text"><b>Address: </b><?php echo e($item->address); ?></p>
                                    <p class="card-text"><?php echo e($item->description); ?></p>
                                    <h5 style="" class="card-title"><b>BDT</b> <?php echo e(round($item->price)); ?></h5>

                                    <a href="<?php echo e(route('venuBooking', $item->id)); ?>" class="btn btn-primary"
                                        style="float: right">Book Now</a>
                                </div>

                            </div>


                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-8 mt-2">
                Total : <?php echo e($list->total()); ?>

                <div class="float-right"><?php echo e($list->appends(Request::all())->links()); ?></div>
            </div>

        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ajax'); ?>
    <script>
        $(document).ready(function() {

            $('#division').on('change', function(e) {
                e.preventDefault();
                $.ajax({
                    type: 'get',
                    url: '<?php echo e(route('getDivsionsZoneList')); ?>',
                    data: {
                        id: $(this).val()
                    },
                    success: function(result) {
                        console.log(result);
                        $('#zone').html(result);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\venue-finder\resources\views/client/venueResult.blade.php ENDPATH**/ ?>