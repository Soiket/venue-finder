

<?php $__env->startSection('main'); ?>

<h1 style="text-align: center">Hi <?php echo e(Auth::user()->name); ?></h1>
<div>
   <h3 style="text-align: center">Welcome to Venue Finder Admin Panel</h3> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\venue-finder\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>