

<?php $__env->startSection('client_main'); ?>
    <div style="height: 200px">


    </div>
    <div class="container">

        <div class="col-md-12">
            <h3>Booking Venues</h3>
            <form action="<?php echo e(route('booking.store')); ?>" method="POST"
                style="background-color: rgb(190, 187, 183); padding:20px; width:50%">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="Date">Check Availibility </label> <i class="fa fa-calendar-check-o fa-2x"
                        aria-hidden="true"></i>
                    <input class="date form-control" type="text" name="date" id="date" placeholder="yyyy-mm-dd"
                        required>
                    <input type="hidden" value="<?php echo e($venue->id); ?>" name="venue_id" id="venue_id">
                </div>
                <div style="background-color: brown" id="result"></div>
                <div class="form-group">
                    <label for="floatingSelect">Payment Method</label>
                    <select class="form-select" id="payment_method" name="payment_method" aria-label="State" required>
                        <option value="">Select One</option>

                        <option value="cash" <?= $booking->payment_method === 'cash' ? 'selected' : '' ?>>Cash</option>
                        <option value="bkash" <?= $booking->payment_method === 'bkash' ? 'selected' : '' ?>>bkash</option>
                        <option value="nagod" <?= $booking->payment_method === 'nagod' ? 'selected' : '' ?>>Nagod</option>
                        <option value="ssl" <?= $booking->payment_method === 'ssl' ? 'selected' : '' ?>>SSL Commeerz
                        </option>
                        <option value="cheque" <?= $booking->payment_method === 'cheque' ? 'selected' : '' ?>>Cheque
                        </option>

                    </select>

                </div>
                <button type="submit" class="btn btn-primary" style="text-align: center">Confirm</button>
            </form>

        </div>

    </div>
    <div style="height: 50px">


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ajax'); ?>
    <script>
        $(document).ready(function() {

            $('#date').on('change', function(e) {

                e.preventDefault();
                $.ajax({
                    type: 'get',
                    url: '<?php echo e(route('bookingDate')); ?>',
                    data: {
                        date: $(this).val(),
                        venue_id: $("#venue_id").val()
                    },
                    success: function(result) {
                        console.log(result);
                        $('#result').html(result);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\venue-finder\resources\views/booking/create.blade.php ENDPATH**/ ?>