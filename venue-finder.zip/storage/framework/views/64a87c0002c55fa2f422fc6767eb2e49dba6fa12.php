

<?php $__env->startSection('customerPanel'); ?>

<section class="section">
   <div class="row">
       <div class="col-lg-12">

           <div class="card">
               <?php if(session()->has('message')): ?>
                   <div style="color:green; float:right">
                       <?php echo e(session()->get('message')); ?>

                   </div>
               <?php endif; ?>
               <div class="card-body">

                   <h5 class="card-title">Booking List</h5>

                   <!-- Table with stripped rows -->
                   <table class="table datatable">
                       <thead>
                           <tr>
                               <th scope="col">#</th>
                               <th scope="col">Venue Name</th>
                               <th scope="col">Price</th>
                               <th scope="col">Booking Date</th>
                               <th scope="col">Payment Method</th>
                               <th scope="col">Status</th>
                           </tr>
                       </thead>
                       <tbody>
                           <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                   <th scope="row"><?php echo e($item->id); ?></th>
                                   <td><?php echo e($item->venue->name); ?></td>
                                   <td><?php echo e($item->price); ?></td>
                                   <td><?php echo e($item->date); ?></td>
                                   <td><?php echo e($item->payment_method); ?></td>
                                   <?php if($item->status == 'pending'): ?>
                                   <td style="background-color: rgb(255, 0, 0)" ><?php echo e($item->status); ?></td>
                                   <?php elseif($item->status == 'confirm'): ?>
                                   <td style="background-color: rgb(75, 255, 4)" ><?php echo e($item->status); ?></td>
                                   <?php elseif($item->status == 'cancel'): ?>
                                   <td style="background-color: rgb(255, 0, 179)" ><?php echo e($item->status); ?></td>
                                   <?php endif; ?>
                               </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                   </table>
                   <!-- End Table with stripped rows -->

               </div>
           </div>
           <form>
               <input type="button" value="Go back!" onclick="history.back()">
           </form>
       </div>
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\venue-finder\resources\views/customer/index.blade.php ENDPATH**/ ?>